#! /usr/bin/env python3
'''
Copyright (c) Quarkslab
Author: S.R
'''
import sys
import os
import fnmatch


def main(outfilename):
    if os.name != "nt":
        print("[-] Error : Sorry, this script works only on Windows")
        
    #creating output file
    outfile = open(outfilename, "w")    
        
    #get windows dir.
    windir = os.getenv("windir")
    if windir is not None:
        print("[+] Found system directory : {}".format(windir))
    else:
        print("[-] Error: Couldn't find system directory")
        
    # get system directory [note that files are hidden by default]
    sysdir = os.path.join(windir, "system32")  
        
    print("[*] Please wait while searching for files, this might take some time.")
    filename_list = list()
    for root, dirnames, filenames in os.walk(sysdir):
        for filename in fnmatch.filter(filenames, 'api-ms-win*.dll'):
            if filename not in filename_list:
                filename_list.append(filename)
                   
    filename_list.sort()
        
    print("[*] OK. Found {} files".format(len(filename_list)))
        
    for filename in filename_list:
        print(filename)
        
    print("[*] Writing to {}".format(outfilename))       
    outfile.writelines('\n'.join(filename_list))
    
    outfile.close()
    
    print("[*] Done. Exiting.")

if __name__ == '__main__':
    if len(sys.argv) == 2:
        main(sys.argv[1])
    else:
        print("[*] Usage: {} <output_file>".format(sys.argv[0]))
        