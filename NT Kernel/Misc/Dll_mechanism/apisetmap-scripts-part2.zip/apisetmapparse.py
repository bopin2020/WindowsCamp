'''
ApiSetSchema DLL parser

(c) Copyright Quarkslab : www.quarkslab.com

Author: S.R
'''
import os
import sys
import ctypes
import apisetmapload

class STRINGDESCRIPTOR(ctypes.Structure):
    _fields_ = [('OffsetDllString', ctypes.c_int32),
                ("StringLength",ctypes.c_int32),
                ("OffsetDllRedirector", ctypes.c_int32)
                ]

class APISETMAP(ctypes.Structure):
    _fields_ = [('Version', ctypes.c_int32),
                ('NumberOfStructs', ctypes.c_int32) ]
    
class DLLREDIRECTOR(ctypes.Structure):
    _fields_ = [("NumberOfRedirections",ctypes.c_uint32)]
    
class REDIRECTION(ctypes.Structure):
    _fields_ = [("OffsetRedirection1", ctypes.c_uint32),
                ("RedirectionLength1", ctypes.c_uint16),
                ("_pad1", ctypes.c_uint16),
                ("OffsetRedirection2", ctypes.c_uint32),
                ("RedirectionLength2", ctypes.c_uint16),
                ("_pad2", ctypes.c_uint16)]   

class Descriptor:
    def __init__(self, mapfile, index):
        self._stringdescriptor = STRINGDESCRIPTOR()
        
        self.offset = ctypes.sizeof(APISETMAP) + (index * ctypes.sizeof(STRINGDESCRIPTOR))
        mapfile.seek(self.offset)
        
        mapfile.readinto(self._stringdescriptor)        
        
        self.OffsetDllString = self._stringdescriptor.OffsetDllString
        self.StringLength = self._stringdescriptor.StringLength 
        self.OffsetDllRedirector = self._stringdescriptor.OffsetDllRedirector
        
        self.string = Utils.getUtf16LEStringAtOffset(mapfile, self.OffsetDllString, self.StringLength) 
                
        mapfile.seek(self.OffsetDllRedirector)
        
        self.dllredirector = DLLREDIRECTOR()
        mapfile.readinto(self.dllredirector) 
        
        self.redirections = list()
        for i in range(self.dllredirector.NumberOfRedirections):
            redir = Redirection(mapfile, self, i)
            self.redirections.append(redir)  
        

class Redirection:
    def __init__(self, mapfile, descriptor, index):  
        self._redirection = REDIRECTION()
        
        offset = (descriptor.OffsetDllRedirector + 
            ctypes.sizeof(DLLREDIRECTOR) + #skip 'NumberOfRedirections'
            (index * ctypes.sizeof(REDIRECTION))) #index depending on number of redir.
        mapfile.seek(offset) 
        mapfile.readinto(self._redirection)
        
        self.OffsetRedirection1 = self._redirection.OffsetRedirection1
        self.RedirectionLength1 = self._redirection.RedirectionLength1
        self.OffsetRedirection2 = self._redirection.OffsetRedirection2
        self.RedirectionLength2 = self._redirection.RedirectionLength2 
        self.RedirectionString1 = Utils.getUtf16LEStringAtOffset(mapfile, self.OffsetRedirection1, self.RedirectionLength1)       
        self.RedirectionString2 = Utils.getUtf16LEStringAtOffset(mapfile, self.OffsetRedirection2, self.RedirectionLength2)
                  
        
class Utils:
    @classmethod  
    def getUtf16LEStringAtOffset(cls, f, offset, length):
        f.seek(offset)
        string = f.read(length)
        return string.decode("utf_16_le") 
    
    @classmethod    
    def getwindir(cls, verbose = False):
        """
        Get Windows directory
        """
        if os.name != "nt":
            print("[-] Error : Sorry, this function works only on Windows") 
                    
        windir = os.getenv("windir")
        if verbose:
            if windir is not None:
                print("[+] Found system directory : {}".format(windir))
            else:
                print("[-] Error: Couldn't find system directory")
            
        return windir 
    
    
class ApiSetMap:
    def __init__(self, mapfilename):
        self.filename = mapfilename
        self.mapfile = open(mapfilename, "r+b")
        
        self._apisetmap = APISETMAP()    
    
        self.mapfile.readinto(self._apisetmap)
        
        self.Version = self._apisetmap.Version
        self.NumberOfStructs = self._apisetmap.NumberOfStructs
        
        self.Descriptors = list()
        
    def parse(self):        
        for i in range(self.NumberOfStructs):
            self.Descriptors.append(Descriptor(self.mapfile, i))
            
    def __del__(self):
        self.close_file()

            
    def close_file(self):
        if not self.mapfile.closed:
            self.mapfile.close()   
            
        try:
            os.remove(self.filename)
        except WindowsError as err:
            #print("[-] Error: {}".format(err))
            pass
        

def main(dllpath): 
    #extract information from apiset (note: the temporary file is deleted after use)
    mapfilename = apisetmapload.extract_apisetmap(dllpath)  
    if mapfilename is None:
        return
    else:
        print("[*] Extracted Api Set Schema to {}".format(mapfilename))
        
        
    print("[*] Starting to parse Api Set Schema !")    
    apisetmap = ApiSetMap(mapfilename)
    
    apisetmap.parse()
    
    print("[*] Version: {}\n[*] Number of Structures: {}\n".format(apisetmap.Version, apisetmap.NumberOfStructs))
    
    for i, descriptor in enumerate(apisetmap.Descriptors):
        print("[*] [{}] Virtual DLL [structure offset: {:#x}]".format(i, descriptor.offset))
        print("\t\tOffsetDllString: {:#x} ; StringLength: {:#x} ; OffsetDllRedirector: {:#x}".format(
            descriptor.OffsetDllString, descriptor.StringLength, descriptor.OffsetDllRedirector))
        print("\t\tVirtual DLL Name: {}".format(descriptor.string))
        print("\t\tNumber of redirections: {}".format(descriptor.dllredirector.NumberOfRedirections))
        for redir in descriptor.redirections:
            print("\t\tOffsetRedirection1: {:#x} ; RedirectionLength1: {:#x} ; OffsetRedirection2: {:#x} ; RedirectionLength2: {:#x}".format(
                redir.OffsetRedirection1, redir.RedirectionLength1, redir.OffsetRedirection2, redir.RedirectionLength2))
            print("\t\t\tRedirection -> String1: {} ; String2: {}".format(redir.RedirectionString1, redir.RedirectionString2))    
    


if __name__ == '__main__':        
    if len(sys.argv) == 1:
        windir = Utils.getwindir(True)
        dllpath = os.path.join(windir, "system32")
        dllpath = os.path.join(dllpath, "apisetschema.dll")
        main(dllpath)
    elif len(sys.argv) == 2:
        main(sys.argv[1])
    else:
        print("[*] Usage: {} <apisetschema.dll>".format(sys.argv[0]))
    