'''
ApiSetSchema section content extractor

(c) Copyright Quarkslab : www.quarkslab.com

Author: S.R
'''

import os
import ctypes
import tempfile

#base windows types
BYTE = ctypes.c_uint8
WORD = ctypes.c_uint16
DWORD = ctypes.c_uint32
IMAGE_SIZEOF_SHORT_NAME = 8

class IMAGE_SECTION_HEADER_UNION(ctypes.Union):
    _fields_ = [('PhysicalAddress', DWORD),
                ('VirtualSize', DWORD),]

class IMAGE_SECTION_HEADER(ctypes.LittleEndianStructure):
    _fields_ = [
        ('Name', BYTE * IMAGE_SIZEOF_SHORT_NAME),
        ('Misc', IMAGE_SECTION_HEADER_UNION),
        ('VirtualAddress', DWORD),
        ('SizeOfRawData', DWORD),
        ('PointerToRawData', DWORD),
        ('PointerToRelocations', DWORD),
        ('PointerToLinenumbers', DWORD),
        ('NumberOfRelocations', WORD),
        ('NumberOfLinenumbers', WORD),
        ('Characteristics', DWORD),]
    
class FileReader:
    def __init__(self, filepath):
        self.file = open(filepath, "rb")        
        
    def __del__(self):
        if not self.file.closed:
            self.file.close()
            
    def read_chunk(self, start, length):
        self.file.seek(start)
        data = self.file.read(length)
        return data
            
    def readinto(self, file_index, struct):
        self.file.seek(file_index)
        sz = ctypes.sizeof(struct)
        data = self.file.read(sz)
        minlen = min(len(data), sz)
        ctypes.memmove(ctypes.addressof(struct), data, minlen)  
        
    def readinto2(self, file_index, struct):
        self.file.seek(file_index)
        self.file.readinto(struct)     


def extract_apisetmap(filepath):
    
    fr = FileReader(filepath)
    #read the first 0x400 bytes of the PE file
    head = fr.read_chunk(0, 0x400)
    #check if ".apiset" can be found
    section_index = head.index(b".apiset")
    if section_index <= 0:
        print("[-] Error couldn't find the \".apiset\" section")
        return None
    else:
        print("[+] Found .apiset section header at {:#x}".format(section_index))
    
    #read the IMAGE_SECTION_HEADER of .apiset section
    ish = IMAGE_SECTION_HEADER()
    fr.readinto(section_index, ish)    
    
    print("[*] SizeOfRawData: {:#x} ; PointerToRawData: {:#x}".format(ish.SizeOfRawData, ish.PointerToRawData))
    
    #write the section content to a temp file
    htemp, tempfilename = tempfile.mkstemp()
    with open(tempfilename, "w+b") as f:
        data = fr.read_chunk(ish.PointerToRawData, ish.SizeOfRawData)
        f.write(data)  
        
    return tempfilename    

       
def getwindir(verbose = False):
    """
    Get Windows directory
    """
    windir = os.getenv("windir")
    if verbose:
        if windir is not None:
            print("[+] Found system directory : {}".format(windir))
        else:
            print("[-] Error: Couldn't find system directory")
        
    return windir 


def main():
    windir = getwindir(True)
    if windir is None:
        return
    
    dllpath = os.path.join(windir, "system32")
    dllpath = os.path.join(dllpath, "apisetschema.dll")
    
    filename = extract_apisetmap(dllpath)
    print("[*] Api Set Schema content written to {}".format(filename))
   

if __name__ == '__main__':
    main()